#include<stdio.h>

enum color
{
	RED = 18, ORANGE, YELLOW = 5, GREEN, BLUE, INDIGO = 14, VIOLET
};

int main()
{
	printf("RED = %d, Orange = %d, YELLOW = %d, GREEN = %d, BLUE = %d, INDIGO = %d, VIOLET = %d\n",RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET);

	return 0;
}
