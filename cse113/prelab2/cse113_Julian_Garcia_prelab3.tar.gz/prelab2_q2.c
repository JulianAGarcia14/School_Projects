#include <stdio.h>
int main()
{
	/* Declares input*/
	int input = 0;
	/* asks user for input*/
	printf("Enter an integer: \n");
	/*receives user's input*/
	scanf("%d", &input);
	/* Begins patented communist immigration quiz for good number*/
	switch (input) {
	case 1:
		printf("My friend, one is weak number, always lose to two.\n");
		break;
	case 3:
		printf("Three is strong number, always beat two. ");
		printf("\n ");
		break;
	default:
		printf("%d? Are you some sort of blue blooded сука блять (dont translate that).\n", input);
	}
	return 0;
}
