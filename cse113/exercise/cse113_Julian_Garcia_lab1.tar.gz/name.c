#include<stdio.h>

int main()
{
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("JJJJJJJJJJJJJJJJJ\n");
printf("        J\n");
printf("        J                                        \n");
printf("        J                              0                      n    nnnnnnnnn\n");
printf("        J                        l                            n  n          n\n");
printf("        J                        l            @@@@@@          n n             n\n");
printf("        J        U          U    l     i    @        @        n                n\n");
printf("        J        U          U    l     i  @            @@     n                n\n");
printf("        J        U          U    l     i  @            @ @    n                n\n");
printf(" J     J         U          U    l     i  @            @ @    n                n\n");
printf(" J    J           U        U     l     i    @        @    @   n                n\n");
printf("  JJJ               UUUUUU       l     i      aaaaaa       @  n                n\n");




/* This is a comment */
return 0;

}
