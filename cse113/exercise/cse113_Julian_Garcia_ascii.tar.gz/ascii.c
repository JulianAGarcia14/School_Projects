#include<stdio.h>

int main()
{
printf("                                   @@@@@@@                                     \n");
printf("                l               @@@@@@@@@@@@                   l               \n");
printf("               ll          @@@   ___________  @@@              ll              \n");
printf("               ll        @    ~`   :::#::: `~      @           ll              \n");
printf("              lll      @    ~`    :::###:::  `~     @@         lll             \n");
printf("              lll      @  ~`    ::::#####::::  `~   @           lll            \n");
printf("             lll      @  ``    ::::#######::::  ``   @          llll           \n");
printf("             llll      @@ ``  ::#############:::: `' @@@        llll           \n");
printf("             llll       @@ `~ ::::#########::::  ~` @@@          llll          \n");
printf("              llll      @@@ `~ ::::######:::: ~`  @@@          llll            \n");
printf("              lllll       @@  `~ :::#####::: ~`  @@            llll            \n");
printf("              llllll        @@@   :::###::: ~`@@@            lllll             \n");
printf("               lllll          @@@   ::#::   @@@            lllll               \n");
printf("                llll               @@@@@@@                  lllllll            \n");
printf("                llllll               @@@                  lllllll              \n");
printf("                  lllllll                             lllllllll                \n");
printf("                  llllllllll                      lllllllllllllll              \n");
printf("                llllllllllllll                   lllllllllllllllll             \n");
printf("                 lllllllllllllll                lllllllllllllllll              \n");
printf("                 lllllllllllllllll           lllllllllllllllllll               \n");
printf("                lllllllllllllllllllll       llllllllllllllll                   \n");
printf("                lllllllllllllllllllllll   lllllllllllllllllllllll              \n");
printf("               llllllllllllllllllllllllllllllllllllllllllllllllll              \n");
printf("               llllllllllllllllllllllllllllllllllllllllllllllllllll            \n");
printf("              lllllllllllllllllllllllllllllllllllllllllllllllllllllll          \n");
                                                                                       /*this os the line */



/* This is a comment */
return 0;

}
