#include<stdio.h>

int main()
{
printf("                                 @@@@@@@@@@@@@@                                \n");
printf("                  l          @@@@@@@@@@@@@@@@@@@@@@@         l                 \n");
printf("                 ll      @@@@@   ___________     @@@@@      ll                 \n");
printf("                 ll    @@@@    ~`   :::#::: `~      @@@@    ll                 \n");
printf("                lll   @@@    ~`    :::###:::  `~     @@@    lll                \n");
printf("                 ll  @@@@  ~`    ::::#####::::  `~   @@@@   ll                 \n");
printf("                lll  @@@  ``    ::::#######::::  ``   @@@   lll                \n");
printf("                 ll    @@@ ``   ::::#######::::  `' @@@     lllll              \n");
printf("                lll    @@@@ `~   ::::#####::::  ~` @@@@     ll                 \n");
printf("                 ll     @@@@  `~  ::::###:::: ~`  @@@@      llll               \n");
printf("                 ll       @@@@  `~  :::#::: ~`  @@@@        lll                \n");
printf("                lll         @@@@@@  ------  @@@@@@          llll               \n");
printf("                llll           @@@@@@@@@@@@@@@@            llll                \n");
printf("                 lll               @@@@@@@@               lllll                \n");
printf("                lllll                                    lllll                 \n");
printf("                  lllllllllllllllllllllllllllllllllllllllllllll                \n");
printf("                  lllllllllllllllllllllllllllllllllllllllllllll                \n");
printf("                llllllllllllllllllllllllllllllllllllllllllllllllll             \n");
printf("                 llllllllllllllllllllllllllllllllllllllllllllll                \n");
printf("                   llllllllllllllllllllllllllllllllllllllllllll                \n");
printf("                  llllllllllllllllllllllllllllllllllllllllllllll               \n");
printf("                   llllllllllllllllllllllllllllllllllllllllllllll              \n");
printf("                  llllllllllllllllllllllllllllllllllllllllllllllll             \n");
printf("                 llllllllllllllllllllllllllllllllllllllllllllllllll            \n");
printf("                llllllllllllllllllllllllllllllllllllllllllllllllllll           \n");
                                                                                       /*this os the line */



/* This is a comment */
return 0;

}
