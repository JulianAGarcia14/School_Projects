#include<stdio.h>

int main()
{
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("\n");
printf("@@@@@@@@@@@@@@@@@\n");
printf("        @\n");
printf("        @                                        \n");
printf("        @                              @                      @    @@@@@@@@\n");
printf("        @                        @                            @  @          @\n");
printf("        @                        @            @@@@@@          @ @             @\n");
printf("        @        @          @    @     @    @        @        @                @\n");
printf("        @        @          @    @     @  @            @@     @                @\n");
printf("        @        @          @    @     @  @            @ @    @                @\n");
printf(" @     @         @          @    @     @  @            @ @    @                @\n");
printf(" @    @           @        @     @     @    @        @    @   @                @\n");
printf("  @@@               @@@@@@       @     @      @@@@@@       @  @                @\n");




/* This is a comment */
return 0;

}
