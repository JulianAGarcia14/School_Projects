var searchData=
[
  ['get_5fdata',['get_data',['../life_8c.html#abc21d58c592162be02b4b065bd191840',1,'get_data(char *s):&#160;life.c'],['../life_8h.html#abc21d58c592162be02b4b065bd191840',1,'get_data(char *s):&#160;life.c']]],
  ['gl_2ec',['gl.c',['../gl_8c.html',1,'']]],
  ['green',['green',['../structcolor__t.html#a85e1636e41c5772cf432e4612ed00310',1,'color_t']]]
];
