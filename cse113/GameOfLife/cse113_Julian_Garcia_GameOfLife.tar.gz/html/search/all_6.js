var searchData=
[
  ['init_5fmatrix',['init_matrix',['../life_8c.html#a6ec790568db50837c9bca273440e585d',1,'init_matrix(int rows, int cols):&#160;life.c'],['../life_8h.html#a6ec790568db50837c9bca273440e585d',1,'init_matrix(int rows, int cols):&#160;life.c']]],
  ['init_5fsdl_5finfo',['init_sdl_info',['../sdl_8h.html#a1094292af49bb6c4abf089ab73a79bb9',1,'sdl.h']]]
];
