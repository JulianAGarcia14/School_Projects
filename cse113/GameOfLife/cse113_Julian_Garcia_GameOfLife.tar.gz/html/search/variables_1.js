var searchData=
[
  ['color',['color',['../structsdl__info__t.html#a793e548fc0386a76cdee71647bd096d4',1,'sdl_info_t']]]
];
