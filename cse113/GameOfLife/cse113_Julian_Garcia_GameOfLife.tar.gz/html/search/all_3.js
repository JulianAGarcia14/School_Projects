var searchData=
[
  ['find_5fsize',['find_size',['../life_8c.html#a37a2fff57fe61212c4b64cf82aee12ef',1,'find_size(int dimension, int sprite):&#160;life.c'],['../life_8h.html#a37a2fff57fe61212c4b64cf82aee12ef',1,'find_size(int dimension, int sprite):&#160;life.c']]],
  ['free_5fmatrix',['free_matrix',['../life_8c.html#aef598dc2445a2e565e24573700e343f8',1,'free_matrix(unsigned char **a, int rows):&#160;life.c'],['../life_8h.html#aef598dc2445a2e565e24573700e343f8',1,'free_matrix(unsigned char **a, int rows):&#160;life.c']]]
];
