var searchData=
[
  ['get_5fdata',['get_data',['../life_8c.html#abc21d58c592162be02b4b065bd191840',1,'get_data(char *s):&#160;life.c'],['../life_8h.html#abc21d58c592162be02b4b065bd191840',1,'get_data(char *s):&#160;life.c']]]
];
