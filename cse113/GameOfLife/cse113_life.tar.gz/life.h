#ifndef LIFE_H_
#define LIFE_H_


#endif
