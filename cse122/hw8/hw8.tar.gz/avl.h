#ifndef AVL_H_
#define AVL_H_

struct avl_node_t {
	int key;
	int height; 		/* balance factor */

	struct avl_node_t *left;
	struct avl_node_t *right;
};

int height(struct avl_node_t *root);
struct avl_node_t *single_rotate_left(struct avl_node_t *x);
struct avl_node_t *single_rotate_right(struct avl_node_t *w);
struct avl_node_t *double_rotate_right(struct avl_node_t *z);
struct avl_node_t *double_rotate_left(struct avl_node_t *z);
struct avl_node_t *insert(struct avl_node_t *root, int key);
/* this performs a bst deletion only */
struct avl_node_t *delete_node(struct avl_node_t *root, int key);
void inorder(struct avl_node_t *node);

#endif
