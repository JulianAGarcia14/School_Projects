#include "avl.h"
#include <stdlib.h>
#include <stdio.h>


int height(struct avl_node_t *root)
{
	if (!root)
		return -1;

	else
		return root->height;
}

int max(int a, int b)
{
	if (a < b)
		return b;
	else
		return a;
}


/* LL new node inserted into the left subtree of the left subtree of the critical node */
struct avl_node_t *single_rotate_left(struct avl_node_t *x)
{
	struct avl_node_t *w = x->left;
	x->left = w->right;
	w->right = x;
	
	x->height = max(height(x->left), height(x->right)) + 1;
	w->height = max(height(w->left), x->height) + 1;
	return w; 		/* new root */
	
}


/* RR new node inserted into the right subtree of the right subtree of the critical node */
struct avl_node_t *single_rotate_right(struct avl_node_t *w)
{
	struct avl_node_t *x = w->right;
	w->right = x->left;
	x->left = w;
	
	w->height = max(height(w->left), height(w->right)) + 1;
	x->height = max(height(x->right), w->height) + 1;
	return x; 		/* new root */
	
}

/* LR rotation new node inserted into the right subtree of the left subtree of the critical node  */
struct avl_node_t *double_rotate_left(struct avl_node_t *z)
{
	z->left = single_rotate_right(z->left);
	return single_rotate_left(z);
}

/* RL rotation new node inserted into the left subtree of the right subtree of the critical node  */
struct avl_node_t *double_rotate_right(struct avl_node_t *z)
{
	z->right = single_rotate_left(z->right);
	return single_rotate_right(z);
}

struct avl_node_t *insert(struct avl_node_t *root, int key)
{
	if (!root) {
		root = malloc(sizeof(struct avl_node_t));
		if (!root) {
			printf("insert: malloc error\n");
			return NULL;
		}
		else {
			root->key = key;
			root->height = 0;
			root->left = NULL;
			root->right = NULL;
		}
		
	}
	else if(key < root->key) { /* left subtree */
		root->left = insert(root->left, key);
		if ((height(root->left) - height(root->right)) == 2) {
			if (key < root->left->key) /* left subtree */
				root = single_rotate_left(root); /* LL */
			else 	/* LR */
				root = double_rotate_left(root);

		}
	}
	else if (key > root->key) { /* right subtree */
		root->right = insert(root->right, key);
		if ((height(root->right) - height(root->left)) == 2) {
			if (key < root->right->key) /* left subtree */
				root = double_rotate_right(root); /* RL */
			else 	/* RR */
				root = single_rotate_right(root);
		}
	}

	root->height = max(height(root->left), height(root->right)) + 1;

	return root;
}


/* this is a delete for a bst not an avl tree */
/* make it an avl deletion by accounting for rotations after you delete a node */
struct avl_node_t *delete_node(struct avl_node_t *root, int key)
{
	struct avl_node_t *tmp;

	/* find node */
	if (root == NULL)
		printf("element not found\n");
	else if(key < root->key) { /* left subtree */
		root->left = delete_node(root->left, key);
	}
	else if (key > root->key) { /* right subtree */
		root->right = delete_node(root->right, key);
	}
	else { 			/* found element */
		if (root->left && root->right) {
			/* two children */
			/* replace with largest in left subtree */
			/* you need to implement the find_max function */
			/* uncomment the next two lines once find_max is implemented */
			/* tmp = find_max(root->left); */
			/* root->key = tmp->key; */
			root->left = delete_node(root->left, root->key);
		}
		else {

			tmp = root;
			/* no children */
			if (root->left == NULL && root->right == NULL)
				root = NULL;
			else if (root->left != NULL) 			/* one child */
				root = root->left;
			else
				root = root->right;

			free(tmp);
		}
	}

	return root;
}


void inorder(struct avl_node_t *node)
{
	if (node != NULL) {
		inorder(node->left);
		printf("%d\n", node->key);
		inorder(node->right);
	}
}

