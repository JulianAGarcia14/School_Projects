#ifndef RANDOM_H_
#define RANDOM_H_

unsigned long nrand(unsigned range);
void seed();

#endif
