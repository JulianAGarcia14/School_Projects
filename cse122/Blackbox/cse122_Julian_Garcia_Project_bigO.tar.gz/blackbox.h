#ifndef BLACKBOX_H
#define BLACKBOX_H

#include <time.h>
#include <stdio.h>
#include <stdlib.h>

void function_1(unsigned long n);
void function_2(unsigned long n);
void function_3(unsigned long *list,  unsigned long n);
void function_4(unsigned long n);
void function_5(unsigned long n);
void function_6(unsigned long *list, unsigned long n);
void function_7(unsigned long n);


#endif
