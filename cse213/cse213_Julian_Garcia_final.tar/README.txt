Jar Files are under artifacts directory.
ClientFrame launches the frame and the client.
In using this program outside of the jars, GomokuFrame handles client connection
and frame creation.