package oop.jgarcia.hw1.two;

/**
 * Simple enumerator for temperature unit
 * @author Julian Garcia
 * @version HW 2, #2
 */
public enum Degrees {
    KELVIN, CELSIUS, FAHRENHEIT
}
