package oop.jgarcia.hw3.one;

/**
 * Simple enumerator for temperature unit
 * @author Julian Garcia
 * @version HW 3, #1
 */
public enum Degrees {
    KELVIN, CELSIUS, FAHRENHEIT
}
