# File-Transfer-using-TCP-Socket-in-C
A simple TCP client-server program written in C. In this program the client read a file and send its data to server. The server then receives the data and write it in a text file.
<br/><br/>
Blog post: https://idiotdeveloper.com/file-transfer-using-tcp-socket-in-c/
<br/>

<img src="img/File Transfer TCP.png">

Use the Makefile to compile the code.
<ul>
<li>make server - to compile the server.</li>
<li>make client- to compile the client.</li>
<li>make all - to compile both the server and client.</li>
</ul>
